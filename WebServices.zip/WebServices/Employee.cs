﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Webservices1
{
    public class Employee
    {
      public   int ID;
      public   string Name;
        //public Employee(int ID,string Name)
        //{
        //    this.ID = ID;
        //    this.Name = Name;
        //}

    }
}