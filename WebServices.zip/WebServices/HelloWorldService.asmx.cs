﻿
using System.Collections.Generic;
using System.Web.Services;

namespace Webservices1
{
    /// <summary>
    /// Summary description for HelloWorldService
    /// </summary>
    [WebService(Description = "A simple web serbice",
        Namespace = "http://tempuri.org/",
        Name = "My web service"
        )]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]

    [System.ComponentModel.ToolboxItem(false)]

    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class HelloWorldService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod]
        public string Helloname(string name)
        {

            return "Hello " + name;
        }

        [WebMethod]
        public int Add (int i,int j)
        {

            return i + j;
        }

        [WebMethod]
        public Employee GetEmployee()
        {

            return new Employee { ID = 1, Name = "Harika" };
        }

        [WebMethod]
        public List<Employee> GetListOfEmployees()
        {
            return new List<Employee>
            {
                 new Employee { ID = 1, Name = "Harika" },
             new Employee { ID = 2, Name = "Lakshmi" }

        };

        }
    }
}
